import UIKit

var str = "Hello, playground"

let miNombreCompleto = "Juan Villalvazo",miFechaDeNacimiento = "1-1-1989",miLugarDeNacimiento = "México",puntoCongelacionAgua = 0



