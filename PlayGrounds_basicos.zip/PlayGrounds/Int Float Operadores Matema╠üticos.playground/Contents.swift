import UIKit

//Enteros

var x = 18

//Flotantes

var y = 18.8


//Operadores aritméticos + - * /

var sumaEnteros = x + 2

var sumaFlotantes = y + 2.2

var suma = Double(x) + y

var division = Float(x) / 5



