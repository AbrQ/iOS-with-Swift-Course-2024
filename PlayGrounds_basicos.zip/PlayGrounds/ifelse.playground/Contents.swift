import UIKit

var edad = 17
var cantidadDinero = 1000
var sexoFemenino = false
                //true
if !((edad >= 18 || cantidadDinero > 250)  && (sexoFemenino)) {
      //false
    
    print("Si puedes entrar al bar ya que eres mayor de edad o tienes dinero suficiente")
} else {
    
    print("No puedes entrar al bar ya que no eres mayor de edad")
    
}
