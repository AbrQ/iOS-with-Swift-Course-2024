import UIKit

//Operador de asignación =

let numeroConstante = 18

//Operadores Aritmeticos + - * /

var numeroVariable = 2

numeroConstante + numeroVariable
numeroConstante - numeroVariable
numeroConstante * numeroVariable
numeroConstante / numeroVariable

//Operadores Compuestos



//numeroVariable = numeroVariable - 2
numeroVariable += 2
numeroVariable -= 2
numeroVariable *= 2
numeroVariable /= 2

//Operadores de comparación
var x = 1
var y = 1

//Igual a ==

x == y

//Diferente a !=

x != y

//Mayor que >

x > y

//Menor que <

x < y

//Mayor o igual que >=

x >= y

//Menor o igual que <=


x <= y
