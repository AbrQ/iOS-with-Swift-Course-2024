/*Import sirve para importar librerias
Una libreria es una coleccion de lineas de código
que podemos usar para no reinventar la rueda.*/
import UIKit

var str = "Hello, playground"
