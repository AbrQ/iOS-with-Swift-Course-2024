import UIKit

var arregloEjemplo = [3,112,4,5,65,8,8,3]

//Operador rango doble lado / two-sided range operator

var subSetArreglo = arregloEjemplo[1...3]

//Operador rango lado unico / one-sided range operator
 var subSetArreglo2 = arregloEjemplo[5...]


var rangoCerrado = 1...5
//1.2.3.4.5
//var subArray = Array(rangoCerrado[0])


//subArray[2]
