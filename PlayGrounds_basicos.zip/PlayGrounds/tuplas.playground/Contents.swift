import UIKit
             /*Nombre,apellido,edad, estatura
var persona = ("Juan","Villalvazo",30,1.86)

persona.0


var (nombre,apellido,edad,estatura) = persona

nombre */


var personaNamedTuples = (nombre:"Juan",apellido:"Villalvazo",edad:30,estatura:1.86)


personaNamedTuples.nombre
