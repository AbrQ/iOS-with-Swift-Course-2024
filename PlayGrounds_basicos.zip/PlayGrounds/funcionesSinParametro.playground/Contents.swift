import UIKit

/*var numeroAleatorio:Int
numeroAleatorio = Int(arc4random_uniform(100))*/

func holaMundo(){

    
  print("Hola Mundo")
    
}

holaMundo()

func sumaDosNumerosCualquiera(){
    
   var numero = 2 + 2
    
    
}

sumaDosNumerosCualquiera()




