import UIKit

var edad = 18
var cantidadDinero = 1000
var sexoFemenino = true
                //true
if edad >= 18   {
 
    print("Si puedes entrar al bar ya que eres mayor de edad")
    
    if cantidadDinero > 250  {
        print(" y ademas tienes dinero")
        
        if  sexoFemenino {
            print("Eres el cliente ideal de este bar poco etico")
        }
        
    }


} else {
    
    print("No puedes entrar al bar ya que no eres mayor de edad")
    
}
